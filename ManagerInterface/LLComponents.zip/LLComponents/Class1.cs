﻿using System;

namespace ChargerLogic
{
    public class Class1
    {
    }
}
